import os
import datetime
from typing import Any

from google.cloud import secretmanager


def get_env_var(
    name: str,
    required: bool = True,
    default: Any = None,
    is_secret: bool = False,
) -> Any:
    """Get an environment variable.

    Args:
        name (str): Name of the env variable.
        required (bool, optional): Script will exit if this
        is True and variable is not set. Defaults to True.
        default (Any, optional): Default value to return in case
        the env variable is not set. Defaults to None.

    Returns:
        Any: Value of the env variable.
    """
    if name not in os.environ and required is True:
        raise RuntimeError(f"Environment variable {name} is required.")
    if is_secret:
        return get_secret(os.environ[name])
    if name not in os.environ:
        return default
    return os.environ[name]


def get_last_run_at() -> datetime:
    """Get last run at datetime based on the poll interval.

    Returns:
        datetime: Time that the script may have been last run at.
    """
    try:
        if int(get_env_var("POLL_INTERVAL", required=False, default=5)) <= 0:
            raise ValueError
        else:
            return datetime.datetime.now() - datetime.timedelta(
                minutes=int(get_env_var("POLL_INTERVAL", required=False, default=5))
            )
    except ValueError:
        raise RuntimeError("Invalid integer provided for value POLL_INTERVAL")


def get_secret(name: str) -> str:
    """
    Access the payload for the given secret version if one exists. The version
    can be a version number as a string (e.g. "5") or an alias (e.g. "latest").
    """

    # Create the Secret Manager client.
    client = secretmanager.SecretManagerServiceClient()

    # Access the secret version.
    response = client.access_secret_version(request={"name": name})
    return response.payload.data.decode("UTF-8")
