from typing import Callable
import jwt
import requests
from base64 import b64encode


DEFAULT_TIMEOUT = 60


class AuthMethod:
    session: requests.Session = requests.Session()

    def refresh(self):
        raise NotImplementedError()

    def paginate(self, *args, **kwargs):
        if "has_next" not in kwargs:
            raise ValueError("has_next is required.")
        if "before_next" not in kwargs:
            raise ValueError("before_next is required.")
        has_next = kwargs.pop("has_next")
        before_next = kwargs.pop("before_next")
        request = requests.Request(*args, **kwargs)
        while True:
            response = self._make_api_call(request)
            response.raise_for_status()
            yield response
            if not has_next(response):
                break
            request = before_next(request, response)

    def _make_api_call(self, request):
        req = self.session.prepare_request(request)
        response = self.session.send(req, timeout=DEFAULT_TIMEOUT)
        response.raise_for_status()
        if response.status_code in [401, 403]:
            try:
                self.refresh()
                req = self.session.prepare_request(request)
                return self.session.send(req, timeout=DEFAULT_TIMEOUT)
            except NotImplementedError:
                return response
        else:
            return response

    def __getattr__(self, name):
        def wrapper(*args, **kwargs):
            request = requests.Request(name, *args, **kwargs)
            return self._make_api_call(request)

        return wrapper


class UsernamePasswordAuth(AuthMethod):
    def __init__(self, username: str, password: str) -> None:
        self.session.auth = (username, password)


class APIKeyAuth(AuthMethod):
    def __init__(self, api_key: str) -> None:
        self.session.headers["Authorization"] = api_key


class OAuthClientCredentialsAuth(AuthMethod):
    def __init__(
        self,
        endpoint: str,
        client_id: str,
        client_secret: str,
        scope: str = None,
        before_request: Callable = None,
    ) -> None:
        data = {
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
        }
        if scope:
            data["scope"] = scope
        request = requests.Request("post", url=endpoint, data=data)
        if before_request:
            request = before_request(request)
        session = requests.Session()
        response = session.send(request.prepare())
        if response.status_code == 200:
            response = response.json()
            access_token = response.get("access_token", "")
            if access_token != "":
                self.session.headers.update(
                    {"Authorization": f"Bearer {access_token}"}
                )
                if "refresh_token" in response:
                    self._refresh_token = response.get("refresh_token", "")


class OAuthPasswordGrantCredentialsAuth(AuthMethod):
    def __init__(
        self,
        endpoint: str,
        username: str,
        password: str,
        client_id: str,
        scope: str = None,
    ) -> None:
        data = {
            "grant_type": "client_credentials",
            "username": username,
            "password": password,
            "client_id": client_id,
        }
        if scope:
            data["scope"] = scope
        response = requests.post(url=endpoint, data=data)
        if response.status_code == 200:
            response = response.json()
            access_token = response.get("access_token", "")
            if access_token != "":
                self.session.headers.update(
                    {"Authorization": f"Bearer {access_token}"}
                )
                if "refresh_token" in response:
                    self._refresh_token = response.get("refresh_token", "")


class HeaderAuth(AuthMethod):
    def __init__(self, username: str, password: str) -> None:
        user_pass = bytes(username + ":" + password)
        encoded_credentials = b64encode(user_pass).decode("ascii")
        encoded_value = "Basic {}".format(encoded_credentials)
        headers = {"Authorization": encoded_value}
        self.session.headers.update(headers)


class OAuthJWTCredentials(AuthMethod):
    def __init__(
        self, endpoint: str, claims, key, algorithm: str, headers
    ) -> None:
        assertion_token = jwt.encode(
            claims, key, algorithm=algorithm, headers=headers
        )
        body = {
            "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
            "assertion": assertion_token,
        }
        response = requests.post(endpoint, headers=headers, data=body)
        response.raise_for_status()
        response = response.json()
        access_token = response.get("access_token")
        if access_token:
            self.session.headers.update(
                {"Authorization": f"Bearer {access_token}"}
            )
            self.refresh_token = response.get("refresh_token")
