import json
import sys
import os
from typing import Optional, Sequence

from .utils import get_env_var
from google.auth.transport import requests as Requests
from google.oauth2 import service_account

AUTHORIZATION_SCOPES = ["https://www.googleapis.com/auth/malachite-ingestion"]
CUSTOMER_ID = get_env_var("CHRONICLE_CUSTOMER_ID")
REGION = get_env_var("CHRONICLE_REGION", required=False, default="us")
SERVICE_ACCOUNT = get_env_var("CHRONICLE_SERVICE_ACCOUNT", is_secret=True)


try:
    SERVICE_ACCOUNT_DICT = json.loads(SERVICE_ACCOUNT)
except json.JSONDecodeError:
    raise RuntimeError("Invalid Service Account JSON provided.")


def initialize_http_session(
    service_account_json: dict,
    scopes: Optional[Sequence[str]] = None,
) -> Requests.AuthorizedSession:
    """Initialize an authenticated session.

    Args:
        service_account_json (dict): Service Account JSON.
        scopes (Optional[Sequence[str]], optional): Required scopes.
        Defaults to None.

    Returns:
        Requests.AuthorizedSession: Authorized session object.
    """
    credentials = service_account.Credentials.from_service_account_info(
        service_account_json,
        scopes=scopes or AUTHORIZATION_SCOPES,
    )
    return Requests.AuthorizedSession(credentials)


def ingest(data: list, log_type: str):
    """ingest with chunk size 1MB to send data to chronicle.

    Args:
        data (list): raw logs of 3P API.
        log_type(str): data_label of the resource
    """
    http_session = initialize_http_session(
        SERVICE_ACCOUNT_DICT, scopes=AUTHORIZATION_SCOPES
    )

    result = []
    index = 0
    NAMESPACE = os.getenv("CHRONICLE_NAMESPACE")
    while index < len(data):
        if (sys.getsizeof(data[index]) + sys.getsizeof(result)) <= 1000000:
            result.append(data[index])
            index += 1
        else:
            _send_logs_to_chronicle(
                http_session,
                result,
                REGION,
                log_type,
                CUSTOMER_ID,
                namespace=NAMESPACE,
            )
            result.clear()
    if result:
        _send_logs_to_chronicle(
            http_session,
            result,
            REGION,
            log_type,
            CUSTOMER_ID,
            namespace=NAMESPACE,
        )


def _send_logs_to_chronicle(
    http_session: Requests.AuthorizedSession,
    log_text: list,
    region: str,
    log_type: str,
    customer_id: str,
    namespace: str = None,
):
    """Sends unstructured log entries to the Chronicle backend for ingestion.
     Args:
        http_session: Authorized session for HTTP requests.
        region: Region of Ingestion API's
        log_type: Log type for a feed.
        customer_id: A string containing the UUID for the Chronicle customer.
        logs_data: A string containing logs.The total size of this string may
        not exceed 1MB or the resultsing request to the ingestion API will
        fail.
    Raises:
      requests.exceptions.HTTPError: HTTP request resulted in an error
      (response.status_code >= 400).
    """

    INGESTION_API_BASE_URL = "malachiteingestion-pa.googleapis.com"
    if region != "us":
        url = ("https://" + region.lower() + "-" + INGESTION_API_BASE_URL + "/v2/unstructuredlogentries:batchCreate")
    else:
        url = ("https://" + INGESTION_API_BASE_URL + "/v2/unstructuredlogentries:batchCreate")

    header = {"Content-Type": "application/json"}
    result = []
    print(f"Attempting to push {len(log_text)} log(s) to Chronicle.")
    for chunk in log_text:
        temp = json.dumps(chunk).encode("utf-8")
        temp = str(temp, "utf-8")
        result.append(temp)
    entries = [{"logText": t} for t in result]
    body = {
        "customerId": customer_id,
        "logType": log_type,
        "entries": entries,
    }
    if namespace:
        body["namespace"] = namespace
    response = http_session.request("POST", url, json=body, headers=header)
    resp_json = {}
    try:
        resp_json = response.json()
        response.raise_for_status()
        if resp_json == {}:
            print(f"{len(log_text)} log(s) pushed successfully to Chronicle.")
    except Exception:
        raise RuntimeError(
            f"Error occurred while pushing logs to Chronicle. "
            f"Status code {response.status_code}. Reason: {resp_json}"
        )
